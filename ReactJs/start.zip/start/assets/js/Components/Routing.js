/**
 * For now, we rely on the router.js script tag to be included
 * in the layout. This is just a helper module to get that object.
 */
export default window.Routing;
